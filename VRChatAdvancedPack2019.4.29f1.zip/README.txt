Thank you for downloading this package.

https://github.com/GPSILVER47/VRChatAdvancedPack2019.4.29f1

VRChatAdvancedPack2019.4.29f1

A All-In-One VRChat Unity Avatar Package made for Toggles + useful tools.

This package is made for object toggles & includes everything you need pre-build. It does not include how to make gestures, sitting etc. animations/emotes.

This is a Unity Package made for VRChat Avatars 3.0 SDK & Unity 2019.4.29f1, which includes:

Latest VRCSDK3-AVATAR-2021.08.04.11.23_Public
Default rigged avatar
A mesh for measuring your height in cm & meter
5 Main Folders:

3.0 Animations (Menu & Parameter Folder thath includes the Parameter & Menu's), (Animation Folder with the Action & FX Layer)
Animations for any animations
Audio
Materials
Objects

Top Menu (Which is the Expressions Button in VRChat. Where you can more Sub Menus, like Emotes, Objects etc or just Toggles)
Two Sub-Menus (Default Emotes & Objects) already added to the Top Menu.
Parameter
3 Expression Menus (Default_Emotes, Objects, SFX)
Default Action Layer & a custom FX Layer for Playable Layers

The materials called "DELETE" are only placeholders. Delete them!

Here is a YouTube tutorial from me https://youtu.be/sTQBgaD1CnI

I've made this package, because some people in the Discord Server from VRChat, had problems doing toggles. The YouTube tutorial didn't helped them. This package + my video could help.

Report any issues.

If this package helped, please let me know via linktree in my profile.

Thank you & i'll see you in VRChat!



-Made by GPSILVER